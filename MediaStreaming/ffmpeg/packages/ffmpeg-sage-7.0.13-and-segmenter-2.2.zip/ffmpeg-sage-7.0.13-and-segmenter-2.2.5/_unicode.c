
#if HAVE_WINSOCK2_H == 1 

wchar_t * __s2ws(char *s)
{	
	int len = strlen(s);
	wchar_t *res = av_malloc((len + 1) * sizeof(wchar_t));
	int i = 0;
	while (*s != 0)
	{
		if (s[0] == '\\' && s[1] == 'u')
		{
			char number [5];			
			int value;
			strncpy(number, s + 2, 4);
			sscanf(number, "%x", &value);
			res[i] = value;
			s+=5;
		}
		else if (s[0] == '\\' && s[1] == '\\')
		{
			res[i] = s[0];
			s += 1;
		}
		else
		{
			res[i] = s[0];	
		}
		++i;
		++s;
	}
	res[i] = 0;
	return res;
}

#endif
