#define stereo_split2(output1, output2, input, samples) \
    do {\
	stereo_split(output1, output2, input, samples); /* prevent "unused" warning */ \
	stereo_split2_a(output1, output2, input, samples, s->input_channels);\
    } while(0);

static void stereo_split2_a(short *output1, short *output2, short *input, int samples, int channels)
{
    int i;
    short l = 0;
    short r = 0;
    
    if (channels == 2) {
        for(i=0;i<samples;i++) {
            /* stereo to stereo */
            l = input[0];
            r = input[1];
        } 
    } else if (channels == 5 || channels == 6) {
        int fl_index = 0;
        int fr_index = 1;            
        int c_index = 2;
        int bl_index = 3;
        int br_index = 4;
        
        for(i=0;i<samples;i++) {
            int fl = fl_index != -1 ? input[fl_index] : 0;
            int fr = fr_index != -1 ? input[fr_index] : 0;
            int c = c_index != -1 ? input[c_index] : 0;
            int bl = bl_index != -1 ? input[bl_index] : 0;
            int br = br_index != -1 ? input[br_index] : 0;
            
            l = av_clip_int16(fl + (0.707 * bl) + (0.707 * c));
            r = av_clip_int16(fr + (0.707 * br) + (0.707 * c));
            *output1++ = l;
            *output2++ = r;
            input += channels;
        }         
    }    
}
