
#ifndef __unicode_h__
#define __unicode_h__

#if HAVE_WINSOCK2_H == 1 

extern wchar_t * __s2ws(char *s);

//#define open() open();

#define open(name, flags, mode) _wopen(__s2ws(name), flags, mode);
// todo typedef instead?
#endif

#endif 
