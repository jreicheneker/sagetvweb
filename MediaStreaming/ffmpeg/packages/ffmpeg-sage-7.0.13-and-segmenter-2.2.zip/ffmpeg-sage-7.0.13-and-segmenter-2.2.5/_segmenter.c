/*
 * Copyright (c) 2009 Chase Douglas
 *
 * Modifications (c) 2009 Matej Knopp, InMethod s.r.o.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License version 2
 * as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#if 0
#include <stdio.h>
#include <libavformat/avformat.h>
#include <libavcodec/opt.h>
#endif 

#ifdef WIN32
#include <io.h>
#include <fcntl.h>
#include <stdio.h>
#endif

static AVStream *segmenter_add_output_stream(AVFormatContext *output_format_context, AVStream *input_stream) 
{
    AVCodecContext *input_codec_context;
    AVCodecContext *output_codec_context;
    AVStream *output_stream;

    output_stream = av_new_stream(output_format_context, 0);
    if (!output_stream) 
    {
        fprintf(stderr, "Could not allocate stream\n");
        exit(1);
    }

    input_codec_context = input_stream->codec;
    output_codec_context = output_stream->codec;

    output_codec_context->codec_id = input_codec_context->codec_id;
    output_codec_context->codec_type = input_codec_context->codec_type;
    output_codec_context->codec_tag = input_codec_context->codec_tag;
    output_codec_context->bit_rate = input_codec_context->bit_rate;
    output_codec_context->extradata = input_codec_context->extradata;
    output_codec_context->extradata_size = input_codec_context->extradata_size;

    if (av_q2d(input_codec_context->time_base) * input_codec_context->ticks_per_frame > av_q2d(input_stream->time_base) && 
        av_q2d(input_stream->time_base) < 1.0/1000) 
    {
        output_codec_context->time_base = input_codec_context->time_base;
        output_codec_context->time_base.num *= input_codec_context->ticks_per_frame;
    }
    else 
    {
        output_codec_context->time_base = input_stream->time_base;
    }

    switch (input_codec_context->codec_type) 
    {
        case CODEC_TYPE_AUDIO:
            output_codec_context->channel_layout = input_codec_context->channel_layout;
            output_codec_context->sample_rate = input_codec_context->sample_rate;
            output_codec_context->channels = input_codec_context->channels;

            output_codec_context->frame_size = input_codec_context->frame_size;

            if ((input_codec_context->block_align == 1 && input_codec_context->codec_id == CODEC_ID_MP3) || input_codec_context->codec_id == CODEC_ID_AC3) 
            {
                output_codec_context->block_align = 0;
            }
            else 
            {
                output_codec_context->block_align = input_codec_context->block_align;
            }
            break;
        case CODEC_TYPE_VIDEO:
            output_codec_context->pix_fmt = input_codec_context->pix_fmt;
            output_codec_context->width = input_codec_context->width;
            output_codec_context->height = input_codec_context->height;
            output_codec_context->has_b_frames = input_codec_context->has_b_frames;

            if (output_format_context->oformat->flags & AVFMT_GLOBALHEADER) 
            {
                output_codec_context->flags |= CODEC_FLAG_GLOBAL_HEADER;
            }
            break;
        default:
            break;
    }

    return output_stream;
}

static void segmenter_close_io(ByteIOContext *context, uint8_t finished)
{
    uint8_t *result_buffer;

    uint32_t len = url_close_dyn_buf(context, &result_buffer);

    if (len > 0 || finished)
    {
        uint32_t network = htonl(finished);
        fwrite(&network, 4, 1, stdout);

        network = htonl(len);
        fwrite(&network, 4, 1, stdout);

        fwrite(result_buffer, len, 1, stdout);
        fflush(stdout);
    }
    av_free(result_buffer);
}

static int segmenter_main(int argc, char **argv)
{
    const char *input;
    unsigned int segment_duration;
    char *segment_duration_check;
    double prev_segment_time = 0;
    unsigned int output_index = 0;
    unsigned int segment_offset = 0;
    AVInputFormat *ifmt;
    AVOutputFormat *ofmt;
    AVFormatContext *ic = NULL;
    AVFormatContext *oc;
    AVStream *video_st = NULL;
    AVStream *audio_st = NULL;
    AVCodec *codec;
    int video_index;
    int audio_index;
    int decode_done;
    int ret;
    int i;

    int err;
    int shift = 1;
    double ts_offset = 0;

    av_log_set_level(AV_LOG_VERBOSE);

    if (argc != 4) 
    {
        fprintf(stderr, "Usage: %s segmenter <segment duration in seconds> <first-segment-index>\n", argv[shift + 0]);
        exit(1);
    }

#ifdef WIN32
	setmode(STDOUT_FILENO, O_BINARY);
#endif
    
    av_register_all();

    input = "pipe:";

    segment_duration = strtoll(argv[shift + 1], &segment_duration_check, 10);
    if (segment_duration_check == argv[shift + 1]) 
    {
        fprintf(stderr, "Segment duration time (%s) invalid\n", argv[shift + 1]);
        exit(1);
    }

    output_index = strtoll(argv[shift + 2], &segment_duration_check, 10);
    segment_offset = output_index;
    if (segment_duration_check == argv[shift + 2]) 
    {
        fprintf(stderr, "First segment index (%s) invalid\n", argv[shift + 2]);
        exit(1);
    }

    ifmt = av_find_input_format("mpegts");
    if (!ifmt) 
    {
        fprintf(stderr, "Could not find MPEG-TS demuxer\n");
        exit(1);
    }

    ret = av_open_input_file(&ic, input, ifmt, 0, NULL);
    if (ret != 0) 
    {
        fprintf(stderr, "Could not open input file, make sure it is an mpegts file: %d\n", ret);
        exit(1);
    }

//    av_set_int(ic, "analyzeduration", 10000000);

    if (av_find_stream_info(ic) < 0) 
    {
        fprintf(stderr, "Could not read stream information\n");
        exit(1);
    }

    ofmt = guess_format("mpegts", NULL, NULL);
    if (!ofmt) 
    {
        fprintf(stderr, "Could not find MPEG-TS muxer\n");
        exit(1);
    }
    
    oc = avformat_alloc_context();
    if (!oc) 
    {
        fprintf(stderr, "Could not allocated output context");
        exit(1);
    }
    oc->oformat = ofmt;

    ofmt->flags |= AVFMT_NOTIMESTAMPS;
//    ofmt->flags |= AVFMT_TS_DISCONT;

    video_index = -1;
    audio_index = -1;

    for (i = 0; i < ic->nb_streams && (video_index < 0 || audio_index < 0); i++) 
    {
        switch (ic->streams[i]->codec->codec_type) 
        {
            case CODEC_TYPE_VIDEO:
                video_index = i;
                ic->streams[i]->discard = AVDISCARD_NONE;
                video_st = segmenter_add_output_stream(oc, ic->streams[i]);
                break;
            case CODEC_TYPE_AUDIO:
                audio_index = i;
                ic->streams[i]->discard = AVDISCARD_NONE;
                audio_st = segmenter_add_output_stream(oc, ic->streams[i]);
                break;
            default:
                ic->streams[i]->discard = AVDISCARD_ALL;
                break;
        }
    }

    if (av_set_parameters(oc, NULL) < 0)
    {
        fprintf(stderr, "Invalid output format parameters\n");
        exit(1);
    }

    dump_format(oc, 0, "", 1);

    if (video_st)
    {
        codec = avcodec_find_decoder(video_st->codec->codec_id);
        if (!codec) 
        {
            fprintf(stderr, "Could not find video decoder, key frames will not be honored\n");
        }

        if (avcodec_open(video_st->codec, codec) < 0) 
        {
            fprintf(stderr, "Could not open video decoder, key frames will not be honored\n");
        }
    }

    ++output_index;

    if (url_open_dyn_buf(&oc->pb) < 0) 
    {
        fprintf(stderr, "Could not open dynamic buffer\n");
        exit(1);
    }

    if ((err = av_write_header(oc)) != 0) 
    {
        fprintf(stderr, "Could not write mpegts header to first output file: %i\n", err);
        exit(1);
    }

    // fprintf(stderr, "Input context has timestamp:%lld, start_time:%lld\n", ic->timestamp, ic->start_time);

    if (video_index != -1)
    {
        ts_offset = (double)(segment_offset * segment_duration) * video_st->time_base.den / video_st->time_base.num;
    }
    else if (audio_index != -1)
    {
        ts_offset = (double)(segment_offset * segment_duration) * audio_st->time_base.den / audio_st->time_base.num;
    }

    fprintf(stderr, "Offsetting timestamps by:%f\n", ts_offset);
    prev_segment_time += segment_offset * segment_duration;

    do 
    {
        double segment_time;
        AVPacket packet;

        decode_done = av_read_frame(ic, &packet);
        if (decode_done < 0) 
        {
            break;
        }

        if (av_dup_packet(&packet) < 0) 
        {
            fprintf(stderr, "Could not duplicate packet");
            av_free_packet(&packet);
            break;
        }

        packet.pts += ts_offset;
        packet.dts += ts_offset;
        // fprintf(stderr, "Packet pts: %f\n", (double)packet.pts * audio_st->time_base.num / audio_st->time_base.den);

        if (video_st && packet.stream_index == video_index && (packet.flags & PKT_FLAG_KEY)) 
        {
            segment_time = (double)video_st->pts.val * video_st->time_base.num / video_st->time_base.den;
        }
        else if (video_index == -1) 
        {
            segment_time = (double)audio_st->pts.val * audio_st->time_base.num / audio_st->time_base.den;
        }
        else 
        {
            segment_time = prev_segment_time;
        }

        if (segment_time - prev_segment_time >= segment_duration) 
        {
            put_flush_packet(oc->pb);

            if ((output_index -1) % 5 == 0)
            {
                fprintf(stderr, "Wrote segment %d\n", output_index - 1);
                fflush(stderr);
            }

            ++output_index;

            prev_segment_time += segment_duration;
            
            segmenter_close_io(oc->pb, 1);
        }
        else
        {
            segmenter_close_io(oc->pb, 0);
        }


        if (url_open_dyn_buf(&oc->pb) < 0) 
        {
            fprintf(stderr, "Could not open dynamic buffer\n");
            break;
	}   

        ret = av_interleaved_write_frame(oc, &packet);
        if (ret < 0) 
        {
            fprintf(stderr, "Could not write frame of stream\n");
            av_free_packet(&packet);
            break;
        }
        else if (ret > 0) 
        {
            fprintf(stderr, "End of stream requested\n");
            av_free_packet(&packet);
            break;
        }

        av_free_packet(&packet);
    } 
    while (!decode_done);

    av_write_trailer(oc);

    if (video_st)
    {
        avcodec_close(video_st->codec);
    }

    for(i = 0; i < oc->nb_streams; i++) 
    {
        av_freep(&oc->streams[i]->codec);
        av_freep(&oc->streams[i]);
    }

    segmenter_close_io(oc->pb, 1);
    av_free(oc);

    fprintf(stderr, "Wrote segment %d -- final\n", output_index - 1);
    fflush(stderr);

    return 0;
}

